﻿namespace Laboratorio5
{
    class Program
    {
        string[] frutas = { "manzana", "platano", "naranja" };
        foreach(string fruta in frutas)
            {
            Console.WriteLine(fruta);
            }
    }
}
