﻿using Laboratorio72;

static void Main(string[] args)
{
    JuegoDeDados j = new JuegoDeDados();
    j.Jugar();
}